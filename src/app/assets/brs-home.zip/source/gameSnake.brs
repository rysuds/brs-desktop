sub gameSnake()
    resetGame()
    if m.mainScreen <> invalid and m.port <> invalid
        port = m.port
        screen = m.mainScreen
    else
        port = createObject("roMessagePort")
        screen = createObject("roScreen", true, m.rect.w, m.rect.h)
        screen.setMessagePort(port)
    end if
    colors = [&hFF0000FF, &h00FF00FF, &h0000FFFF, &hFFFF00FF, &hFF00FFFF, &h00FFFFFF, &hFFFFFFFF]
    keys = ["exit", "", "up", "down", "left", "right", "ok"]
    clock = createObject("roTimespan")
    clock.mark()
    eatSound = createObject("roAudioResource", "navmulti")
    dieSound = createObject("roAudioResource", "deadend")
    snakeBmp = createObject("roBitmap", {width: m.snake[0].s, height: m.snake[0].s})
    snakeBmp.clear(&h4CAF50FF)
    headBmp = createObject("roBitmap", {width: m.snake[0].s, height: m.snake[0].s})
    headBmp.clear(&h2E7D32FF)
    foodBmp = createObject("roBitmap", {width: m.food.s, height: m.food.s})
    foodBmp.clear(colors[Rnd(colors.count()-1)])
    fontReg = createObject("roFontRegistry")
    titleFont = fontReg.getDefaultFont(32, true, false)
    scoreFont = fontReg.getDefaultFont(24, false, false)
    bigFont = fontReg.getDefaultFont(56, true, false)
    smallFont = fontReg.getDefaultFont(18, false, false)
    m.gameOver = false
    m.paused = false
    headerH = 50
    while true
        event = port.getMessage()
        if type(event) = "roUniversalControlEvent"
            key = event.getInt()
            keyName = ""
            if key < keys.count() then keyName = keys[key]
            if keyName = "exit"
                exit while
            else if m.gameOver
                if keyName = "ok"
                    resetGame()
                    snakeBmp.clear(&h4CAF50FF)
                    headBmp.clear(&h2E7D32FF)
                    foodBmp.clear(colors[Rnd(colors.count()-1)])
                    m.gameOver = false
                    clock.mark()
                end if
            else if keyName <> invalid and keyName <> "" and keyName <> "ok"
                if keyName = "up" and m.move <> "down" then m.move = keyName
                if keyName = "down" and m.move <> "up" then m.move = keyName
                if keyName = "left" and m.move <> "right" then m.move = keyName
                if keyName = "right" and m.move <> "left" then m.move = keyName
            end if
        else
            if not m.gameOver
                ticks = clock.totalMilliseconds()
                if ticks > m.speed
                    clock.mark()
                    head = {x: m.snake[0].x, y: m.snake[0].y, s: m.snake[0].s}
                    moveSnake(head)
                    checkBoundaries(head, headerH)
                    m.snake.unshift(head)
                    if checkDeath(head)
                        dieSound.trigger(50)
                        m.gameOver = true
                        if m.score > m.highScore then m.highScore = m.score
                    else if checkCollision(head, m.food)
                        eatSound.trigger(50)
                        m.score++
                        newFood(headerH)
                        foodBmp.clear(colors[Rnd(colors.count()-1)])
                        if m.score mod 5 = 0 and m.speed > 40
                            m.speed -= 5
                        end if
                    else
                        m.snake.pop()
                    end if
                end if
            end if
            screen.clear(&h1A1A2EFF)
            ' Header bar
            screen.drawRect(0, 0, m.rect.w, headerH, &h0D0D1AFF)
            screen.drawText("SNAKE", 30, 8, &h4CAF50FF, titleFont)
            screen.drawText("Score: " + m.score.toStr(), 200, 14, &hCCCCCCFF, scoreFont)
            screen.drawText("High: " + m.highScore.toStr(), 380, 14, &h888888FF, scoreFont)
            screen.drawText("Speed: " + int(100 / m.speed * 100).toStr() + "%", 540, 14, &h888888FF, scoreFont)
            ' Border line
            screen.drawRect(0, headerH, m.rect.w, 2, &h333355FF)
            if not m.gameOver
                ' Draw food
                screen.drawObject(m.food.x, m.food.y, foodBmp)
                ' Draw snake body
                for i = m.snake.count() - 1 to 1 step -1
                    screen.drawObject(m.snake[i].x, m.snake[i].y, snakeBmp)
                end for
                ' Draw snake head
                screen.drawObject(m.snake[0].x, m.snake[0].y, headBmp)
                ' Instructions
                screen.drawText("Arrow keys: move  |  Back: exit", 460, m.rect.h - 26, &h555555FF, smallFont)
            else
                ' Game over overlay
                screen.drawRect(m.rect.w / 2 - 220, m.rect.h / 2 - 130, 440, 260, &h0D0D1ACC)
                screen.drawRect(m.rect.w / 2 - 218, m.rect.h / 2 - 128, 436, 256, &h1A1A2EFF)
                screen.drawText("GAME OVER", m.rect.w / 2 - 155, m.rect.h / 2 - 110, &hF44336FF, bigFont)
                screen.drawText("Score: " + m.score.toStr(), m.rect.w / 2 - 55, m.rect.h / 2 - 30, &hEEEEEEFF, scoreFont)
                screen.drawText("High Score: " + m.highScore.toStr(), m.rect.w / 2 - 80, m.rect.h / 2 + 10, &hAAAAAAFF, scoreFont)
                screen.drawRect(m.rect.w / 2 - 100, m.rect.h / 2 + 55, 200, 40, &h4CAF50FF)
                screen.drawText("Press OK", m.rect.w / 2 - 45, m.rect.h / 2 + 62, &hFFFFFFFF, scoreFont)
                screen.drawText("Press BACK to exit", m.rect.w / 2 - 80, m.rect.h / 2 + 108, &h666666FF, smallFont)
            end if
            screen.swapBuffers()
        end if
    end while
end sub

sub resetGame()
    m.rect = {w: 1280, h: 720}
    cellSize = 15
    startX = int(m.rect.w / 2 / cellSize) * cellSize
    startY = int(m.rect.h / 2 / cellSize) * cellSize
    m.snake = [{x: startX, y: startY, s: cellSize}]
    m.move = "up"
    m.score = 0
    m.speed = 100
    if m.highScore = invalid then m.highScore = 0
    newFood(50)
end sub

sub moveSnake(head as object)
    if m.move = "up"
        head.y -= head.s
    else if m.move = "down"
        head.y += head.s
    else if m.move = "left"
        head.x -= head.s
    else if m.move = "right"
        head.x += head.s
    end if
end sub

sub newFood(headerH as integer)
    foodSize = 10
    collided = true
    while collided
        m.food = {x: Rnd(m.rect.w - foodSize), y: headerH + 10 + Rnd(m.rect.h - headerH - foodSize - 20), s: foodSize}
        collided = false
        for each bodyPart in m.snake
            if checkCollision(bodyPart, m.food)
                collided = true
                exit for
            end if
        end for
    end while
end sub

sub checkBoundaries(head as object, headerH as integer)
    if head.x < 0
        head.x = m.rect.w - head.s
    else if head.x > m.rect.w - head.s
        head.x = 0
    end if
    if head.y < headerH + 2
        head.y = m.rect.h - head.s
    else if head.y > m.rect.h - head.s
        head.y = headerH + 2
    end if
end sub

function checkDeath(head as object) as boolean
    index = 0
    for each bodyPart in m.snake
        if index > 0 and checkCollision(head, bodyPart)
            return true
        end if
        index++
    end for
    return false
end function

function checkCollision(head as object, obj as object) as boolean
    return head.x < obj.x + obj.s and head.x + head.s > obj.x and head.y < obj.y + obj.s and head.y + head.s > obj.y
end function
