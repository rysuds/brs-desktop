' ********************************************************************************************************
' ********************************************************************************************************
' **  BrightScript TV: Home Screen - http://github.com/lvcabral/brs-home
' **
' **  Copyright © 2023-2025 Marcelo Lv Cabral - http://lvcabral.com
' ********************************************************************************************************
' ********************************************************************************************************
Library "v30/bslCore.brs"

sub Main(params)
    'Constants
    m.codes = bslUniversalControlEventCodes()
    m.colors = { black: &hFF, white: &hFFFFFFFF, darkgray: &h0F0F0FFF, blue: &h0000FFFF, transparent: &h00000000 }
    m.appInfo = CreateObject("roAppInfo")
    m.skin = m.appInfo.getValue("skin")
    'Util objects
    m.port = CreateObject("roMessagePort")
    m.clock = CreateObject("roTimespan")
    m.audioPlayer = CreateObject("roAudioPlayer")
    m.audioPort = CreateObject("roMessagePort")
    m.audioPlayer.SetMessagePort(m.audioPort)
    m.sounds = LoadSounds(true)
    m.files = CreateObject("roFileSystem")
    m.manifest = GetManifestArray()
    m.inSimulator = InSimulator()
    'bs:disable-next-line 1129
    m.ndk = CreateObject("roNDK")
    SetupMenuScreen(1280, 720)
    ShowHomeScreenMenu(m.port)
end sub

sub ShowHomeScreenMenu(port = invalid)
    m.theme = GetTheme()
    screen = CreateGridScreen(false)
    if port = invalid then port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)
    content = GetContent(screen)
    screen.SetContentList(content)
    selected = ""
    while true
        screen.visible = false
        msg = screen.Wait(1000)
        if msg = invalid
            updateClock(screen)
            screen.show(false)
            screen.visible = false
        else if msg.isScreenClosed()
            exit while
        else if msg.isListItemFocused()
            idx = msg.GetIndex()
            screen.SetListName((idx + 1).toStr() + " of " + content.Count().toStr() + " items")
            item = content[idx]
            if item = invalid
                sps = idx mod screen.columns
                first = idx - sps
                last = idx - sps + screen.columns - 1
                for i = first to Min(last, content.Count() - 1)
                    screen.SetContentItem(i, { id: i + 1, HDPosterUrl: GetAppIcon(i) })
                next
            end if
            screen.show()
        else if msg.isListItemSelected()
            item = content[msg.GetIndex()]
            if item <> invalid
                selected = m.apps[item.id - 1].id
                selectedPath = m.apps[item.id - 1].path
                if selected <> invalid and selectedPath <> invalid
                    if selectedPath.startsWith("brs:")
                        'Internal app/game or shortcut
                        if selected = "snake-game"
                            gameSnake()
                        else if InSimulator()
                            m.ndk.start("SDKLauncher", ["ChannelId=" + selected])
                        else if selected = "tv-off" or selected = "turn-off"
                            ' Exit app when running on a Roku device
                            exit while
                        else
                            print "Unknown internal app:'"; selected
                        end if
                    else if m.skin = "arcade" and (selectedPath.startsWith("http") or selectedPath.startsWith("file:"))
                        'Web app
                        HideMainScreen()
                        RunWebApp(selectedPath)
                    else if m.inSimulator
                        'BrightScript app
                        m.ndk.start("SDKLauncher", ["ChannelId=" + selected])
                        screen.close()
                        exit while
                    else
                        print "Cannot launch other BrightScript apps from a Roku device!"
                    end if
                    screen.show()
                end if
            end if
        end if
    end while
end sub

function GetContent(screen as object) as object
    m.apps = []
    appManager = CreateObject("roAppManager")
    if m.skin = "arcade"
        m.apps = GetShortcuts()
    else if InSimulator()
        m.apps = appManager.GetAppList(true)
        m.apps.append(GetShortcuts())
    else
        m.apps = appManager.GetAppList()
        m.apps.append(GetShortcuts())
    end if
    content = []
    appsCount = m.apps.count()
    screen.SetListName("1 of " + appsCount.toStr() + " items")
    updateClock(screen)
    screen.Show()
    for l = 1 to appsCount
        id = m.apps[l - 1]?.id
        title = "App " + l.toStr()
        if m.apps[l - 1]?.title <> invalid
            title = m.apps[l - 1].title
        end if
        if id = "dev" and title = m.manifest.title
            continue for
        end if
        if id = "dev"
            title += " (dev)"
        end if
        content.Push({ id: l, title: title, HDPosterUrl: GetAppIcon(l - 1) })
    next
    return content
end function

function GetShortcuts() as object
    filePath = "pkg:/assets/" + m.skin + ".json"
    return ParseJSON(ReadAsciiFile(filePath))?.apps
end function

function GetAppIcon(appId as integer) as string
    filePath = ""
    app = m.apps[appId]
    if app?.icon <> invalid
        if app.icon.startsWith("pkg:")
            filePath = app.icon
        else if app.icon.startsWith("http") or app.icon.startsWith("file:")
            filePath = CacheFile(app.icon, "app-" + appId.toStr() + ".png", true)
        end if
    else
        filePath = CacheFile("http://192.168.1.221:8060/query/icon/" + app.id, "app-" + appId.toStr() + ".png", true)
    end if
    if filePath.trim() = "" or not m.files.Exists(filePath)
        'Fallback to placeholder
        filePath = "pkg:/images/grid/placeholder.png"
    end if
    return filePath
end function

sub SetupMenuScreen(width, height)
    m.mainScreen = CreateObject("roScreen", true, width, height)
    m.mainScreen.SetAlphaEnable(true)
    m.mainScreen.SetMessagePort(m.port)
end sub

sub HideMainScreen()
    m.mainScreen.clear(m.colors.transparent)
    m.mainScreen.SwapBuffers()
end sub

function GetTheme() as object
    theme = {
        BackgroundColor: "#000000",
        OverhangSliceHD: "pkg:/themes/" + m.skin + "/background-hd.png",
        GridScreenBackgroundColor: "#000000",
        ListScreenHeaderText: "#FFFFFFFF",
        ListScreenDescriptionText: "#FFFFFFFF",
        ListItemHighlightText: "#FFD801FF"
    }
    return theme
end function

function UpdateClock(screen)
    screen.canvas.setLayer(3, [{
        Text: getCurrentTime(),
        TextAttrs: { color: m.theme.ListScreenDescriptionText, font: "Small", HAlign: "Right" },
        TargetRect: { x: 0, y: 40, w: 1226, h: 60 }
    }])
end function
