' ********************************************************************************************************
' ********************************************************************************************************
' **  BrightScript TV: Home Screen - http://github.com/lvcabral/brs-home
' **
' **  Copyright © 2023-2025 Marcelo Lv Cabral - http://lvcabral.com
' ********************************************************************************************************
' ********************************************************************************************************

' ------- Bitmap Functions -------

function ScaleBitmap(bitmap as object, scale as float, simpleMode = false as boolean) as object
    if bitmap = invalid or bitmap.GetWidth() = 0 then return bitmap
    if scale = 1.0
        scaled = bitmap
    else if scale = int(scale) or simpleMode
        scaled = CreateObject("roBitmap", { width: int(bitmap.GetWidth() * scale), height: int(bitmap.GetHeight() * scale), alphaenable: bitmap.GetAlphaEnable() })
        scaled.DrawScaledObject(0, 0, scale, scale, bitmap)
    else
        region = CreateObject("roRegion", bitmap, 0, 0, bitmap.GetWidth(), bitmap.GetHeight())
        region.SetScaleMode(1)
        scaled = CreateObject("roBitmap", { width: int(bitmap.GetWidth() * scale), height: int(bitmap.GetHeight() * scale), alphaenable: bitmap.GetAlphaEnable() })
        scaled.DrawScaledObject(0, 0, scale, scale, region)
    end if
    return scaled
end function

function ScaleToSize(bitmap as object, width as integer, height as integer, ratio = true as boolean) as object
    if bitmap = invalid then return bitmap
    if ratio and bitmap.GetWidth() <= width and bitmap.GetHeight() <= height
        scaled = bitmap
    else
        region = CreateObject("roRegion", bitmap, 0, 0, bitmap.GetWidth(), bitmap.GetHeight())
        region.SetScaleMode(1)
        if ratio
            if bitmap.GetWidth() > bitmap.GetHeight()
                scale = width / bitmap.GetWidth()
            else
                scale = height / bitmap.GetHeight()
            end if
            scaled = CreateObject("roBitmap", { width: int(bitmap.GetWidth() * scale), height: int(bitmap.GetHeight() * scale), alphaenable: bitmap.GetAlphaEnable() })
            scaled.DrawScaledObject(0, 0, scale, scale, region)
        else
            scaleX = width / bitmap.GetWidth()
            scaleY = height / bitmap.GetHeight()
            scaled = CreateObject("roBitmap", { width: width, height: height, alphaenable: bitmap.GetAlphaEnable() })
            scaled.DrawScaledObject(0, 0, scaleX, scaleY, region)
        end if
    end if
    return scaled
end function

'------- Device Check Functions -------

function IsHD()
    di = CreateObject("roDeviceInfo")
    return (di.GetUIResolution().height >= 720)
end function

function InSimulator() as boolean
    di = CreateObject("roDeviceInfo")
    return di.hasFeature("simulation_engine")
end function

'------- Registry Functions -------

function GetRegistryString(key as string, default = "") as string
    sec = CreateObject("roRegistrySection", "brs-home")
    if sec.Exists(key)
        return sec.Read(key)
    end if
    return default
end function

sub SaveRegistryString(key as string, value as string)
    sec = CreateObject("roRegistrySection", "brs-home")
    sec.Write(key, value)
    sec.Flush()
end sub

'------- String Functions -------

function itostr(i as integer) as string
    return i.ToStr()
end function

function zeroPad(number as integer, length = 2 as integer) as string
    text = number.toStr()
    if text.Len() < length then text = string(length - text.Len(), "0") + text
    return text
end function

function padCenter(text as string, size as integer) as string
    if Len(text) > size then text.Left(text, size)
    if Len(text) < size
        left = ""
        right = ""
        for c = 1 to size - Len(text)
            if c mod 2 = 0
                left += " "
            else
                right += " "
            end if
        next
        text = left + text + right
    end if
    return text
end function

function padLeft(text as string, size as integer) as string
    if Len(text) > size
        return text.Left(size)
    else if Len(text) < size
        text += StringI(size - Len(text), 32)
    end if
    return text
end function

'------- Download Functions --------

function CacheFile(url as string, file as string, overwrite = false as boolean) as string
    tmpFile = "tmp:/" + file
    if overwrite or not m.files.Exists(tmpFile)
        http = CreateObject("roUrlTransfer")
        http.SetCertificatesFile("common:/certs/ca-bundle.crt")
        http.AddHeader("Content-Type", "application/json")
        http.EnableEncodings(true)
        http.SetUrl(url)
        ret = http.GetToFile(tmpFile)
        if ret <> 200
            'print "File not cached! http return code: "; ret; " - "; url
            tmpFile = ""
        end if
    end if
    return tmpFile
end function

' ------- Aux Functions -------

function getCurrentTime() as string
    ' get the current date and time value
    dt = CreateObject("roDateTime")
    dt.toLocalTime()
    ' get the hour, minute, and second components
    hour = dt.GetHours()
    minute = dt.GetMinutes()
    second = dt.GetSeconds()
    ' convert the hour to 12 hours format and get the AM/PM indicator
    ampm = "am"
    if hour = 0
        hour = 12
    else if hour = 12
        ampm = "pm"
    else if hour > 12
        hour = hour - 12
        ampm = "pm"
    end if
    minuteStr = right("0" + minute.toStr(), 2)
    return Substitute("{0}:{1} {2}", hour.toStr(), minuteStr, ampm)
end function

function GetManifestArray() as object
    manifest = ReadAsciiFile("pkg:/manifest")
    lines = manifest.Split(chr(10))
    aa = {}
    for each line in lines
        if line <> ""
            entry = line.Split("=")
            if entry.count() >= 2
                aa.AddReplace(entry[0], entry[1].Trim())
            end if
        end if
    end for
    return aa
end function

function GetAppVersion()
    ma = m.manifest
    version = "v" + ma.major_version + "." + ma.minor_version + "." + ma.build_version
    return version
end function

function Min(a, b)
    if a < b then return a else return b
end function
