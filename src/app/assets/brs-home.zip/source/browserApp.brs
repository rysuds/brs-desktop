' ********************************************************************************************************
' ********************************************************************************************************
' **  BrightScript TV: Home Screen - http://github.com/lvcabral/brs-home
' **
' **  Copyright © 2024-2025 Marcelo Lv Cabral - http://lvcabral.com
' ********************************************************************************************************
' ********************************************************************************************************
Library "RokuBrowser.brs"

sub runWebApp(appUrl as string)
    options = {
        hbbtv: false,
        transparentBackground: true,
        windowSize: "1280x720",
        accessLocalFiles: true,
        devtoolsPort: 9222,
        ' Uncomment to enable SharedArrayBuffer to run on real devices
        ' extraDebugArguments: ["--enable-features=SharedArrayBuffer"],
    }
    try
        'bs:disable-next-line
        RokuBrowser(m.ndk, appUrl, options)
    catch e
        print "Error: "; e?.message
    end try
end sub